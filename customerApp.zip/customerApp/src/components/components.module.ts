import { NgModule } from '@angular/core';
import { BlahComponent } from './blah/blah';
@NgModule({
	declarations: [BlahComponent],
	imports: [],
	exports: [BlahComponent]
})
export class ComponentsModule {}
