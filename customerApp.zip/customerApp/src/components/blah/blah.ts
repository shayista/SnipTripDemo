import { Component } from '@angular/core';

/**
 * Generated class for the BlahComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'blah',
  templateUrl: 'blah.html'
})
export class BlahComponent {

  text: string;

  constructor() {
    console.log('Hello BlahComponent Component');
    this.text = 'Hello World';
  }

}
